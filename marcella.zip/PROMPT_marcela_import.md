# HSos — Marcela Students Import
## Claude Code Prompt — One Shot, No Guessing

---

## Step 0 — Read project context first

Read these files before doing anything:
- `STATUS.md`
- `SCHEMA.md`  
- `RULES.md`

---

## Step 1 — Introspect ALL relevant tables from the live production DB

Run the following SQL against production (wmqmonjnmgtoilxfqqkv.supabase.co).
Use the Supabase MCP tool. Do NOT skip any table.

```sql
-- clients
SELECT column_name, data_type, is_nullable, column_default
FROM information_schema.columns WHERE table_name = 'clients' ORDER BY ordinal_position;

SELECT pg_get_constraintdef(oid) FROM pg_constraint
WHERE conrelid = 'clients'::regclass AND contype IN ('c','u');

-- packages
SELECT column_name, data_type, is_nullable, column_default
FROM information_schema.columns WHERE table_name = 'packages' ORDER BY ordinal_position;

SELECT pg_get_constraintdef(oid) FROM pg_constraint
WHERE conrelid = 'packages'::regclass AND contype IN ('c','u');

-- sessions
SELECT column_name, data_type, is_nullable, column_default
FROM information_schema.columns WHERE table_name = 'sessions' ORDER BY ordinal_position;

SELECT pg_get_constraintdef(oid) FROM pg_constraint
WHERE conrelid = 'sessions'::regclass AND contype IN ('c','u');

-- vendors (to get Marcela's UUID)
SELECT id, name, vendor_type FROM vendors WHERE name ILIKE '%marcela%' OR name ILIKE '%sancho%';
```

After running these, build a complete picture of:
- Every NOT NULL column without a default (must be included in INSERT)
- Every CHECK constraint (allowed enum values)
- Every UNIQUE constraint (for ON CONFLICT logic)
- Marcela's exact UUID from the vendors table

---

## Step 2 — The normalized data

The data has already been normalized. Read this file:
`marcela_normalized.json`

It contains:
- `clients` — 22 clients with email, name, section, active flag
- `packages` — 22 packages with email, rate, total_sessions, sessions_done, section
- `sessions` — 597 sessions with client_email, session_date, status (done/planned), rate_usd

---

## Step 3 — Map data to real DB columns

Based on the schema you introspected in Step 1, map each field:

For `clients`:
- Map: email → email, name → full_name (or name — check which exists), active → active/is_active
- Find: what other NOT NULL columns exist that need a value

For `packages`:
- Map: total_sessions → total_sessions (or sessions_total — check), sessions_done → sessions_used
- Find: what is the status column called, what values are allowed
- Find: is there a name/label column for the package
- Find: does vendor_id exist and what type is it

For `sessions`:
- Map: session_date → session_date, status → status, rate_usd → rate_usd
- Find: does hours column exist, is it required
- Find: does billed column exist, what is its default
- Find: what status values are allowed (done/planned vs done/cancelled/etc)

---

## Step 4 — Generate the SQL file

Output file: `migrations/018_seed_marcela_students.sql`

Requirements:
- Use temp tables to map email → UUID so sessions can reference the correct client
- Marcela's vendor UUID: use the exact UUID you found in Step 1
- `gen_random_uuid()` for all new PKs
- No ON CONFLICT on sessions (no unique constraint)
- ON CONFLICT (email) DO NOTHING on clients if email has a unique constraint — otherwise plain INSERT
- Wrap everything in `BEGIN; ... COMMIT;`
- DROP temp tables before COMMIT
- `NOTIFY pgrst, 'reload schema';` before COMMIT
- Only include columns that actually exist in the DB (verified in Step 1)
- Group INSERT VALUES by section for readability

Structure:
```
1. CREATE TEMP TABLE for email→client_id mapping
2. INSERT clients (skip existing by email if unique constraint exists)
3. CREATE TEMP TABLE for email→package_id mapping  
4. INSERT packages
5. INSERT sessions (597 rows, reference temp tables for IDs)
6. DROP temp tables
7. NOTIFY + COMMIT
8. Verification queries as comments at bottom
```

---

## Step 5 — Validate before saving

Before saving the file, mentally check:
- Every INSERT column exists in the real schema (verified in Step 1)
- No hardcoded UUIDs except Marcela's (which you looked up)
- Every NOT NULL column without a default has a value
- Enum values match exactly (e.g. 'done' not 'Done', 'planned' not 'scheduled')
- The SQL would run cleanly on an empty table

If anything is uncertain — query the DB again rather than guessing.

---

## Step 6 — Report

After saving the file, report:
1. Marcela's vendor UUID used
2. Any columns from the normalized data that were skipped (not in DB schema)
3. Any default values you had to invent
4. Total rows: clients / packages / sessions
5. Any warnings about data quality

Do NOT run the SQL. Save the file only.
